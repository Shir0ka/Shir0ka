/*INITIALIZE deck of card
DEAL two cards to player and two cards to dealer

DISPLAY player's cards and one of dealer's cards

WHILE player's hand value is less than 21
  PROMPT player to hit or stand
  IF player chooses to hit
    DEAL another card to player
  END IF
END WHILE

IF player's hand value is over 21
  DECLARE dealer as the winner
  END GAME
END IF

WHILE dealer's hand value is less than 17
  DEAL another card to dealer
END WHILE

IF dealer's hand value is over 21
  DECLARE player as the winner
ELSE
  COMPARE player and dealer's hand values
    IF player's hand value is higher
      DECLARE player as the winner
    ELSE
      DECLARE dealer as the winner
    END IF
END IF
DISPLAY result
*/